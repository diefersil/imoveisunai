<div class="admin-houzez-header">
	<h2 class="admin-houzez-logo"><?php echo houzez_theme_branding_logo(); ?></h2> 
	<div class="admin-houzez-tag"><?php esc_html_e('Current version', 'houzez'); ?> <?php echo HOUZEZ_THEME_VERSION; ?></div>
</div>