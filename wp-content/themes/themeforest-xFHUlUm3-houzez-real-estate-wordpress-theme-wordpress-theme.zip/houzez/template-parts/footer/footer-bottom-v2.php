<div class="footer-bottom-wrap footer-bottom-wrap-v2">
	<div class="container">
		
		<?php get_template_part('template-parts/footer/social'); ?>

		<?php get_template_part('template-parts/footer/logo'); ?>

		<?php get_template_part('template-parts/footer/nav'); ?>

		<?php get_template_part('template-parts/footer/copy-rights'); ?>

	</div><!-- container -->
</div><!-- footer-top-wrap -->