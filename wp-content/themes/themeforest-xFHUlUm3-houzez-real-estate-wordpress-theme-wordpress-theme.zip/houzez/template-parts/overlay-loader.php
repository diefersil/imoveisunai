<div class="houzez-overlay-loading houzez-hidden">
	<div class="overlay-placeholder">
		<div class="loader-ripple spinner">
			<div class="bounce1"></div>
			<div class="bounce2"></div>
			<div class="bounce3"></div>
		</div>
	</div>
</div>